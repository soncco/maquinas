-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 10-08-2012 a las 15:22:54
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `maquinas`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `admin`
-- 

CREATE TABLE `admin` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador del administrador',
  `nombres` varchar(45) NOT NULL COMMENT 'Nombre completo del administrador',
  `usuario` varchar(45) NOT NULL COMMENT 'Nombre de usuario',
  `password` varchar(32) NOT NULL COMMENT 'Contraseña',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usuario_UNIQUE` (`usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Administradores del sistema\n' AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `admin`
-- 

INSERT INTO `admin` VALUES (1, 'Nelida', 'nelida', '6c93b8f63b22c3340e1878ed18c1dd41');
INSERT INTO `admin` VALUES (2, 'Rolfi', 'rolfi', '6c93b8f63b22c3340e1878ed18c1dd41');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alquiler`
-- 

CREATE TABLE `alquiler` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Numero de alquiler',
  `idcliente` int(11) NOT NULL COMMENT 'Identificador del cliente',
  `idmaquina` int(11) NOT NULL COMMENT 'Identificador de la máquina',
  `idlugar` int(11) NOT NULL,
  `recibo` varchar(45) NOT NULL COMMENT 'Recibo de pago en caja',
  `minutos` int(11) NOT NULL COMMENT 'Tiempo de alquiler en minutos',
  `fecha` timestamp NOT NULL default '2012-07-23 00:00:00' COMMENT 'Fecha y hora del alquiler',
  `terminado` tinyint(4) NOT NULL default '0' COMMENT 'Indica si el alquiler ha terminado',
  `observaciones` text NOT NULL COMMENT 'Observaciones o apuntes',
  `combustiblenro` int(11) NOT NULL COMMENT 'Vale de combustible',
  `combustiblecan` float NOT NULL COMMENT 'Cantidad de combustible',
  `anulado` tinyint(4) NOT NULL default '0',
  `creado` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `fk_alquiler_cliente1` (`idcliente`),
  KEY `fk_alquiler_maquina1` (`idmaquina`),
  KEY `fk_alquiler_lugar1` (`idlugar`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Registro de alquileres' AUTO_INCREMENT=83 ;

-- 
-- Volcar la base de datos para la tabla `alquiler`
-- 

INSERT INTO `alquiler` VALUES (1, 5, 2, 8, '2741', 240, '2012-07-31 00:00:00', 0, '', 1225, 8, 0, '2012-07-26 10:13:28');
INSERT INTO `alquiler` VALUES (2, 7, 1, 9, '2744', 60, '2012-07-30 00:00:00', 0, '', 1226, 2, 0, '2012-07-26 10:15:59');
INSERT INTO `alquiler` VALUES (3, 6, 1, 9, '2742', 60, '2012-07-30 00:00:00', 0, '', 1226, 2, 0, '2012-07-26 10:20:51');
INSERT INTO `alquiler` VALUES (4, 4, 3, 1, '2743', 30, '2012-07-26 00:00:00', 0, '', 1226, 1, 0, '2012-07-26 10:36:46');
INSERT INTO `alquiler` VALUES (5, 8, 3, 3, '2712', 30, '2012-07-26 00:00:00', 0, '', 2712, 1, 0, '2012-07-26 10:42:53');
INSERT INTO `alquiler` VALUES (6, 9, 4, 10, '2746', 60, '2012-08-02 00:00:00', 0, '', 1224, 2, 0, '2012-07-26 12:45:46');
INSERT INTO `alquiler` VALUES (7, 10, 4, 3, '2749', 90, '2012-08-02 00:00:00', 0, '', 1224, 3, 0, '2012-07-26 13:03:14');
INSERT INTO `alquiler` VALUES (8, 11, 3, 11, '2750', 60, '2012-07-30 00:00:00', 0, '', 1226, 2, 0, '2012-07-30 09:12:14');
INSERT INTO `alquiler` VALUES (9, 12, 3, 12, '2752', 300, '2012-07-31 00:00:00', 0, '', 1229, 10, 0, '2012-07-30 09:51:35');
INSERT INTO `alquiler` VALUES (10, 13, 3, 12, '2754', 120, '2012-07-31 00:00:00', 0, '', 1229, 4, 0, '2012-07-30 10:02:56');
INSERT INTO `alquiler` VALUES (11, 14, 3, 13, '2756', 30, '2012-07-30 00:00:00', 0, '', 1226, 1, 0, '2012-07-30 10:47:58');
INSERT INTO `alquiler` VALUES (12, 15, 1, 14, '2758', 420, '2012-08-01 00:00:00', 0, '', 1229, 14, 0, '2012-07-30 10:54:23');
INSERT INTO `alquiler` VALUES (13, 16, 4, 5, '2757', 60, '2012-08-01 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 10:57:50');
INSERT INTO `alquiler` VALUES (14, 17, 4, 15, '2759', 60, '2012-08-01 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 11:01:13');
INSERT INTO `alquiler` VALUES (15, 18, 2, 16, '2760', 60, '2012-07-31 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 11:14:57');
INSERT INTO `alquiler` VALUES (16, 18, 4, 16, '2761', 60, '2012-08-01 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 11:16:05');
INSERT INTO `alquiler` VALUES (17, 19, 4, 17, '2765', 60, '2012-08-02 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 12:07:36');
INSERT INTO `alquiler` VALUES (18, 20, 2, 7, '2768', 60, '2012-07-31 00:00:00', 0, '', 1228, 2, 0, '2012-07-30 16:01:29');
INSERT INTO `alquiler` VALUES (19, 21, 3, 12, '2770', 60, '2012-07-31 00:00:00', 0, '', 1230, 2, 0, '2012-07-31 09:22:26');
INSERT INTO `alquiler` VALUES (20, 21, 3, 12, '2771', 300, '2012-08-02 00:00:00', 0, '', 1232, 10, 0, '2012-07-31 09:26:32');
INSERT INTO `alquiler` VALUES (21, 22, 2, 18, '2772', 60, '2012-08-03 00:00:00', 0, '', 1231, 2, 0, '2012-07-31 09:30:35');
INSERT INTO `alquiler` VALUES (22, 23, 4, 5, '2773', 30, '2012-08-01 00:00:00', 0, '', 1231, 1, 0, '2012-07-31 09:33:59');
INSERT INTO `alquiler` VALUES (23, 24, 4, 17, '2774', 30, '2012-08-02 00:00:00', 0, '', 1231, 1, 0, '2012-07-31 10:07:34');
INSERT INTO `alquiler` VALUES (24, 25, 4, 19, '2775', 60, '2012-08-07 00:00:00', 0, '', 1231, 2, 0, '2012-07-31 10:17:36');
INSERT INTO `alquiler` VALUES (25, 26, 2, 21, '2777', 30, '2012-08-03 00:00:00', 0, '', 1231, 1, 0, '2012-07-31 10:44:02');
INSERT INTO `alquiler` VALUES (26, 27, 4, 1, '2783', 30, '2012-08-01 00:00:00', 0, '', 1231, 1, 0, '2012-07-31 16:06:43');
INSERT INTO `alquiler` VALUES (27, 15, 1, 14, '2784', 60, '2012-08-01 00:00:00', 0, '', 1232, 2, 0, '2012-08-01 09:27:37');
INSERT INTO `alquiler` VALUES (28, 28, 2, 22, '2785', 60, '2012-08-03 00:00:00', 0, '', 1231, 2, 0, '2012-08-01 09:32:25');
INSERT INTO `alquiler` VALUES (29, 30, 4, 14, '2786', 90, '2012-08-13 00:00:00', 0, '', 1233, 3, 0, '2012-08-01 09:42:51');
INSERT INTO `alquiler` VALUES (30, 31, 4, 14, '2788', 90, '2012-08-02 00:00:00', 0, '', 1231, 3, 0, '2012-08-01 09:56:40');
INSERT INTO `alquiler` VALUES (31, 32, 3, 19, '2778', 60, '2012-08-03 00:00:00', 0, '', 1232, 2, 0, '2012-08-01 11:09:46');
INSERT INTO `alquiler` VALUES (32, 33, 4, 13, '2793', 90, '2012-08-02 00:00:00', 0, '', 1231, 3, 0, '2012-08-01 12:00:40');
INSERT INTO `alquiler` VALUES (33, 34, 4, 24, '2795', 150, '2012-08-07 00:00:00', 0, '', 1233, 5, 0, '2012-08-01 15:27:12');
INSERT INTO `alquiler` VALUES (34, 35, 2, 25, '2797', 60, '2012-08-06 00:00:00', 0, '', 1233, 2, 0, '2012-08-01 16:12:43');
INSERT INTO `alquiler` VALUES (35, 36, 2, 26, '2796', 60, '2012-08-06 00:00:00', 0, '', 1233, 2, 0, '2012-08-01 16:15:37');
INSERT INTO `alquiler` VALUES (36, 4, 4, 7, '2798', 30, '2012-08-06 00:00:00', 0, '', 1233, 1, 0, '2012-08-02 09:45:52');
INSERT INTO `alquiler` VALUES (37, 37, 2, 24, '2799', 240, '2012-08-08 00:00:00', 0, '', 1233, 8, 0, '2012-08-02 11:10:56');
INSERT INTO `alquiler` VALUES (38, 38, 4, 11, '2800', 60, '2012-08-07 00:00:00', 0, '', 1233, 2, 0, '2012-08-02 12:21:21');
INSERT INTO `alquiler` VALUES (39, 39, 4, 7, '2802', 30, '2012-08-07 00:00:00', 0, '', 1233, 1, 0, '2012-08-02 16:52:36');
INSERT INTO `alquiler` VALUES (40, 40, 4, 22, '2804', 30, '2012-08-07 00:00:00', 0, '', 1233, 1, 0, '2012-08-03 09:47:18');
INSERT INTO `alquiler` VALUES (41, 41, 2, 26, '2805', 240, '2012-08-08 00:00:00', 0, '', 1233, 8, 0, '2012-08-03 12:06:23');
INSERT INTO `alquiler` VALUES (42, 42, 3, 4, '2807', 60, '2012-08-06 00:00:00', 0, '', 1232, 2, 0, '2012-08-06 09:34:45');
INSERT INTO `alquiler` VALUES (43, 43, 3, 27, '2808', 90, '2012-08-06 00:00:00', 0, '', 1232, 3, 0, '2012-08-06 09:51:03');
INSERT INTO `alquiler` VALUES (44, 44, 3, 5, '2809', 30, '2012-08-06 00:00:00', 0, '', 1232, 1, 0, '2012-08-06 09:55:09');
INSERT INTO `alquiler` VALUES (45, 45, 3, 22, '2810', 30, '2012-08-06 00:00:00', 0, '', 1232, 1, 0, '2012-08-06 09:57:54');
INSERT INTO `alquiler` VALUES (46, 5, 3, 1, '2813', 30, '2012-08-07 00:00:00', 0, '', 1232, 1, 0, '2012-08-06 10:29:25');
INSERT INTO `alquiler` VALUES (47, 46, 2, 28, '2814', 60, '2012-08-09 00:00:00', 0, '', 1235, 2, 0, '2012-08-06 11:20:44');
INSERT INTO `alquiler` VALUES (48, 47, 1, 22, '2815', 30, '2012-08-07 00:00:00', 0, '', 1231, 1, 0, '2012-08-07 09:14:36');
INSERT INTO `alquiler` VALUES (49, 48, 3, 1, '2816', 30, '2012-08-07 00:00:00', 0, '', 1231, 1, 0, '2012-08-07 09:17:58');
INSERT INTO `alquiler` VALUES (50, 49, 1, 8, '2817', 30, '2012-08-07 00:00:00', 0, '', 1231, 1, 0, '2012-08-07 09:41:14');
INSERT INTO `alquiler` VALUES (51, 50, 3, 26, '2818', 120, '2012-08-08 00:00:00', 0, '', 1231, 4, 0, '2012-08-07 09:49:39');
INSERT INTO `alquiler` VALUES (52, 51, 3, 17, '2819', 60, '2012-08-10 00:00:00', 0, '', 1231, 2, 0, '2012-08-07 09:53:05');
INSERT INTO `alquiler` VALUES (53, 52, 3, 5, '2820', 60, '2012-08-08 00:00:00', 0, '', 1231, 2, 0, '2012-08-07 10:52:38');
INSERT INTO `alquiler` VALUES (54, 53, 3, 1, '2821', 60, '2012-08-09 00:00:00', 0, '', 1231, 2, 0, '2012-08-07 11:03:12');
INSERT INTO `alquiler` VALUES (55, 54, 3, 19, '2822', 30, '2012-08-08 00:00:00', 0, '', 1231, 1, 0, '2012-08-07 11:06:11');
INSERT INTO `alquiler` VALUES (56, 55, 4, 29, '2825', 480, '2012-08-14 00:00:00', 0, '', 1237, 16, 0, '2012-08-07 12:45:00');
INSERT INTO `alquiler` VALUES (57, 56, 2, 30, '2826', 180, '2012-08-09 00:00:00', 0, '', 1237, 6, 0, '2012-08-07 14:30:03');
INSERT INTO `alquiler` VALUES (58, 57, 3, 29, '2827', 360, '2012-08-13 00:00:00', 0, '', 1236, 12, 0, '2012-08-07 14:53:57');
INSERT INTO `alquiler` VALUES (59, 58, 4, 31, '2828', 30, '2012-08-13 00:00:00', 0, '', 1237, 1, 0, '2012-08-08 09:14:57');
INSERT INTO `alquiler` VALUES (60, 16, 3, 5, '2829', 30, '2012-08-08 00:00:00', 0, '', 1232, 1, 0, '2012-08-08 09:53:56');
INSERT INTO `alquiler` VALUES (61, 50, 3, 26, '2830', 60, '2012-08-08 00:00:00', 0, '', 1234, 2, 0, '2012-08-08 10:04:05');
INSERT INTO `alquiler` VALUES (62, 59, 3, 3, '2832', 30, '2012-08-10 00:00:00', 0, '', 1236, 1, 0, '2012-08-08 11:36:49');
INSERT INTO `alquiler` VALUES (63, 35, 2, 25, '2833', 90, '2012-08-09 00:00:00', 0, '', 1237, 3, 0, '2012-08-08 12:07:48');
INSERT INTO `alquiler` VALUES (64, 61, 3, 23, '2834', 60, '2012-08-10 00:00:00', 0, '', 1236, 2, 0, '2012-08-08 12:49:51');
INSERT INTO `alquiler` VALUES (65, 62, 3, 9, '2835', 60, '2012-08-10 00:00:00', 0, '', 1236, 2, 0, '2012-08-08 13:06:09');
INSERT INTO `alquiler` VALUES (66, 63, 4, 2, '2836', 120, '2012-08-15 00:00:00', 0, '', 1237, 4, 0, '2012-08-08 14:30:29');
INSERT INTO `alquiler` VALUES (67, 64, 3, 19, '2837', 60, '2012-08-10 00:00:00', 0, '', 1236, 2, 0, '2012-08-09 10:05:39');
INSERT INTO `alquiler` VALUES (68, 65, 3, 19, '2838', 60, '2012-08-10 00:00:00', 0, '', 1236, 2, 0, '2012-08-09 10:35:41');
INSERT INTO `alquiler` VALUES (69, 66, 2, 12, '2840', 480, '2012-08-16 00:00:00', 0, '', 1238, 16, 0, '2012-08-09 11:20:13');
INSERT INTO `alquiler` VALUES (70, 37, 4, 24, '2842', 120, '2012-08-13 00:00:00', 0, '', 1238, 4, 0, '2012-08-09 12:06:19');
INSERT INTO `alquiler` VALUES (71, 67, 3, 3, '2845', 30, '2012-08-09 00:00:00', 0, '', 1237, 1, 0, '2012-08-09 15:11:22');
INSERT INTO `alquiler` VALUES (72, 68, 4, 2, '2847', 60, '2012-08-15 00:00:00', 0, '', 1238, 2, 0, '2012-08-09 16:21:38');
INSERT INTO `alquiler` VALUES (73, 69, 2, 25, '2849', 60, '2012-08-10 00:00:00', 0, '', 1238, 2, 0, '2012-08-09 16:43:38');
INSERT INTO `alquiler` VALUES (74, 70, 4, 5, '2850', 30, '2012-08-10 00:00:00', 0, '', 1236, 1, 0, '2012-08-10 09:12:42');
INSERT INTO `alquiler` VALUES (75, 71, 2, 32, '2851', 120, '2012-08-20 00:00:00', 0, '', 1238, 4, 0, '2012-08-10 09:53:27');
INSERT INTO `alquiler` VALUES (76, 16, 4, 3, '2853', 60, '2012-08-11 00:00:00', 0, '', 1237, 2, 0, '2012-08-10 10:09:26');
INSERT INTO `alquiler` VALUES (77, 72, 4, 26, '2854', 120, '2012-08-15 00:00:00', 0, '', 1238, 4, 0, '2012-08-10 10:12:06');
INSERT INTO `alquiler` VALUES (78, 73, 3, 12, '2856', 300, '2012-08-14 00:00:00', 0, '', 1239, 10, 0, '2012-08-10 10:19:01');
INSERT INTO `alquiler` VALUES (79, 74, 1, 3, '2857', 30, '2012-08-15 00:00:00', 0, '', 1239, 1, 0, '2012-08-10 10:35:03');
INSERT INTO `alquiler` VALUES (80, 75, 4, 7, '2858', 30, '2012-08-13 00:00:00', 0, '', 1238, 1, 0, '2012-08-10 11:16:20');
INSERT INTO `alquiler` VALUES (81, 76, 4, 19, '2860', 60, '2012-08-11 00:00:00', 0, '', 1237, 2, 0, '2012-08-10 13:02:20');
INSERT INTO `alquiler` VALUES (82, 46, 4, 28, '2861', 60, '2012-08-13 00:00:00', 0, '', 1237, 2, 0, '2012-08-10 13:04:20');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cliente`
-- 

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador del cliente',
  `nombres` varchar(45) NOT NULL COMMENT 'Nombres',
  `apaterno` varchar(45) NOT NULL COMMENT 'Apellido Paterno',
  `amaterno` varchar(45) NOT NULL COMMENT 'Apellido Materno',
  `dni` varchar(11) default NULL COMMENT 'Documento de identidad',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Clientes de las maquinas' AUTO_INCREMENT=78 ;

-- 
-- Volcar la base de datos para la tabla `cliente`
-- 

INSERT INTO `cliente` VALUES (1, 'Isabel', 'AuccapiÃ±a', 'Quispe', '');
INSERT INTO `cliente` VALUES (2, 'Wilbert', 'Huaman', 'Malaga', '');
INSERT INTO `cliente` VALUES (3, 'Brauli', 'Soncco', 'Pimentel', '');
INSERT INTO `cliente` VALUES (4, 'NAZARIO', 'HUAMAN', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (5, 'DOLORES', 'CONCHA', 'RAYME', '');
INSERT INTO `cliente` VALUES (6, 'OCTAVIO', 'HUAMAN', 'AUCCAPIÃ‘A', '');
INSERT INTO `cliente` VALUES (7, 'Angelino', 'Lazo', 'Quispe', '');
INSERT INTO `cliente` VALUES (8, 'SATURNINA', 'QUISPE', 'AYMA', '');
INSERT INTO `cliente` VALUES (9, 'VICENTE', 'CCOSCCO', 'Quispe', '');
INSERT INTO `cliente` VALUES (10, 'VICTORIA', 'APAZA', 'AYMA', '');
INSERT INTO `cliente` VALUES (11, 'MARISOL', 'QUISPE', 'NAVARRO', '');
INSERT INTO `cliente` VALUES (12, 'RUBEN', 'ALLER', 'PACHECO', '');
INSERT INTO `cliente` VALUES (13, 'RUDECINDO', 'HUAMAN', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (14, 'GERMAN', 'ALMONTE', 'AUCCAPUMA', '');
INSERT INTO `cliente` VALUES (15, 'FLORENCIO', 'SAHUARAURA', 'APAZA', '');
INSERT INTO `cliente` VALUES (16, 'CELIA', 'QUISPE', 'FLORES', '');
INSERT INTO `cliente` VALUES (17, 'EUFEMIA', 'VILCA', 'QUISPE', '');
INSERT INTO `cliente` VALUES (18, 'HORTENCIA', 'CERF', 'MORALES', '');
INSERT INTO `cliente` VALUES (19, 'CELIA', 'SERRANO', 'DE LOAIZA', '');
INSERT INTO `cliente` VALUES (20, 'EUSEBIA', 'ACCOSTUPA', 'CHACCACANTA', '');
INSERT INTO `cliente` VALUES (21, 'FELIX', 'QUISPE', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (22, 'AMADOR', 'QUISPE', 'LEZAMA', '');
INSERT INTO `cliente` VALUES (23, 'JUAN', 'HUARANCCA', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (24, 'CONSTANTINA', 'QUISPE', 'LEZAMA', '');
INSERT INTO `cliente` VALUES (25, 'JUAN', 'ACCOSTUPA', 'QUISPE', '');
INSERT INTO `cliente` VALUES (26, 'JOSEFINA', 'QUISPE', 'RAMOS', '');
INSERT INTO `cliente` VALUES (27, 'LUISA', 'CHAVEZ', 'AUCCAPUMA', '');
INSERT INTO `cliente` VALUES (28, 'JOSE', 'HUAMAN', 'LEVITA', '');
INSERT INTO `cliente` VALUES (29, 'COSTANTINO', 'SARAYASI', 'BISA', '');
INSERT INTO `cliente` VALUES (30, 'CONSTANTINO', 'SARAYASI', 'BISA', '');
INSERT INTO `cliente` VALUES (31, 'BERTHA', 'SANTOYO', 'QUISPE', '');
INSERT INTO `cliente` VALUES (32, 'MARCOS', 'APAZA', 'LEON', '');
INSERT INTO `cliente` VALUES (33, 'CARMEN', 'GIL', 'BARCENA', '');
INSERT INTO `cliente` VALUES (34, 'CERAFINA', 'GUTIERREZ', 'ESCOBAR', '');
INSERT INTO `cliente` VALUES (35, 'JACINTA', 'ARANIBAR', 'ATAU', '');
INSERT INTO `cliente` VALUES (36, 'JUSTINA', 'PEREZ', 'ARTEAGA', '');
INSERT INTO `cliente` VALUES (37, 'LEOCADIO', 'CURI', 'CUSIHUAMAN', '');
INSERT INTO `cliente` VALUES (38, 'VIRGINIA', 'HUAMAN', 'VARGAS', '');
INSERT INTO `cliente` VALUES (39, 'GENARO', 'CCOYA', 'AUCCAPIÃ‘A', '');
INSERT INTO `cliente` VALUES (40, 'DAVID', 'CCOYA', 'CCOLOMA', '');
INSERT INTO `cliente` VALUES (41, 'CELMIRA', 'CAMACHO', 'ALARCON', '');
INSERT INTO `cliente` VALUES (42, 'FRANCISCA', 'SALAZAR', 'ANDIA', '');
INSERT INTO `cliente` VALUES (43, 'JUAN', 'BERNE', 'SEGOVIA', '');
INSERT INTO `cliente` VALUES (44, 'EPIFANIO', 'APAZA', 'AYACHO', '');
INSERT INTO `cliente` VALUES (45, 'LUIS', 'NAURAY', 'PUMALLOCLLA', '');
INSERT INTO `cliente` VALUES (46, 'JOVITA', 'HUAMAN', 'VARGAS', '');
INSERT INTO `cliente` VALUES (47, 'PASCUAL', 'ANCCO', 'PARI', '');
INSERT INTO `cliente` VALUES (48, 'GERMAN', 'SEGOVIA', 'HUALLPA', '');
INSERT INTO `cliente` VALUES (49, 'FRANKLIN', 'SUYLLO', 'CCOYA', '');
INSERT INTO `cliente` VALUES (50, 'EULOGIO', 'SUYLLO', 'AUCCACUSI', '');
INSERT INTO `cliente` VALUES (51, 'HUGO', 'APAZA', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (52, 'JOSE', 'ALMONTE', 'AUCCAPUMA', '');
INSERT INTO `cliente` VALUES (53, 'JUANA', 'AUCCACUSI', 'QUISPE', '');
INSERT INTO `cliente` VALUES (54, 'VILMA', 'QUISPE', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (55, 'RICARDO', 'HUAMAN', 'HUALLPA', '');
INSERT INTO `cliente` VALUES (56, 'MARIO', 'ROJAS', 'AUCCACUSI', '');
INSERT INTO `cliente` VALUES (57, 'EULOGIO', 'HUAMAN', 'HUALLPA', '');
INSERT INTO `cliente` VALUES (58, 'JUSTINA', 'LEZAMA', 'DE QUISPE', '');
INSERT INTO `cliente` VALUES (59, 'CEFERINO', 'SUYLLO', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (60, 'ADUARDO', 'APAZA', 'LEON', '');
INSERT INTO `cliente` VALUES (61, 'EDUARDO', 'APAZA', 'LEON', '');
INSERT INTO `cliente` VALUES (62, 'NICASIO', 'FLORES', 'CAZORLA', '');
INSERT INTO `cliente` VALUES (63, 'BERNARDINO', 'AUCCACUSI', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (64, 'ALEJANDRO', 'QUISPE', 'APAZA', '');
INSERT INTO `cliente` VALUES (65, 'MARCELINA', 'CAZORLA', 'MARISCAL', '');
INSERT INTO `cliente` VALUES (66, 'MIGUEL', 'QUISPE', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (67, 'CIRILO', 'HUARANCCA', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (68, 'ESTER', 'AUCCACUSI', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (69, 'CRISPIN', 'VILLALBA', 'GARCIA', '');
INSERT INTO `cliente` VALUES (70, 'JUSTINIANO', 'CONCHA', 'RAYME', '');
INSERT INTO `cliente` VALUES (71, 'RAYMUNDO', 'SAHUARAURA', 'APAZA', '');
INSERT INTO `cliente` VALUES (72, 'DOMINGO', 'HUAMAN', 'SUYLLO', '');
INSERT INTO `cliente` VALUES (73, 'MARIO', 'CJUIRO', 'HUAMAN', '');
INSERT INTO `cliente` VALUES (74, 'DOLORES', 'CONCHA', 'RAYME', '');
INSERT INTO `cliente` VALUES (75, 'VIDAL', 'FLORES', 'CAZORLA', '');
INSERT INTO `cliente` VALUES (76, 'JUAN', 'ACCOSTUPA', 'QUISPE', '');
INSERT INTO `cliente` VALUES (77, 'NICASIA', 'ALVARES', 'VD DE CUSIHUMAN', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `combustible`
-- 

CREATE TABLE `combustible` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador del recibo',
  `cantidad` float NOT NULL COMMENT 'Cantidad de combustible en galones',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Vales de combustible\n' AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `combustible`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `lugar`
-- 

CREATE TABLE `lugar` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador de lugar',
  `nombre` varchar(45) NOT NULL COMMENT 'Nombre del lugar',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Lugares donde se alquila' AUTO_INCREMENT=33 ;

-- 
-- Volcar la base de datos para la tabla `lugar`
-- 

INSERT INTO `lugar` VALUES (1, 'Tambocunca');
INSERT INTO `lugar` VALUES (2, 'Muscarumi');
INSERT INTO `lugar` VALUES (3, 'Farapata');
INSERT INTO `lugar` VALUES (4, 'Ccaccafranca');
INSERT INTO `lugar` VALUES (5, 'Maicha');
INSERT INTO `lugar` VALUES (6, 'Matero');
INSERT INTO `lugar` VALUES (7, 'MAYUNURAY');
INSERT INTO `lugar` VALUES (8, 'TINCOC');
INSERT INTO `lugar` VALUES (9, 'IYUNPAMPA');
INSERT INTO `lugar` VALUES (10, 'ALTOSPAMPA');
INSERT INTO `lugar` VALUES (11, 'AMARU');
INSERT INTO `lugar` VALUES (12, 'SAN SALVADOR');
INSERT INTO `lugar` VALUES (13, 'CHALLPU');
INSERT INTO `lugar` VALUES (14, 'ROSAS CCASA');
INSERT INTO `lugar` VALUES (15, 'NIÃ‘OC');
INSERT INTO `lugar` VALUES (16, 'PATACALLE');
INSERT INTO `lugar` VALUES (17, 'IVIMPAMPA');
INSERT INTO `lugar` VALUES (18, 'PUNACCASA');
INSERT INTO `lugar` VALUES (19, 'MALQUIHUAYCCO');
INSERT INTO `lugar` VALUES (20, 'CAPULICHAYOC');
INSERT INTO `lugar` VALUES (21, 'CAPULICHAYOC');
INSERT INTO `lugar` VALUES (22, 'CCOLCCARERA');
INSERT INTO `lugar` VALUES (23, 'MALQUIHUAYCCO');
INSERT INTO `lugar` VALUES (24, 'BELLAVISTA');
INSERT INTO `lugar` VALUES (25, 'HUACHANCCAY');
INSERT INTO `lugar` VALUES (26, 'CHILLARAY');
INSERT INTO `lugar` VALUES (27, 'PATACALLE');
INSERT INTO `lugar` VALUES (28, 'CHACACHIMPA');
INSERT INTO `lugar` VALUES (29, 'LLAULLIRAY');
INSERT INTO `lugar` VALUES (30, 'PUYTOC');
INSERT INTO `lugar` VALUES (31, 'CCOMERPUNCU');
INSERT INTO `lugar` VALUES (32, 'IMQUILCOCHA');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mantenimiento`
-- 

CREATE TABLE `mantenimiento` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador del manteminiento',
  `idmaquina` int(11) NOT NULL COMMENT 'Identificador del mantemiento',
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP COMMENT 'Fecha del último mantenimiento',
  PRIMARY KEY  (`id`,`idmaquina`),
  KEY `fk_mantenimiento_maquina1` (`idmaquina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Registro de mantenimientos' AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `mantenimiento`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `maquina`
-- 

CREATE TABLE `maquina` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador de la máquina',
  `descripcion` varchar(45) NOT NULL COMMENT 'Descripción de la máquina',
  `estado` enum('a','m') NOT NULL default 'a' COMMENT 'Estado actual de la máquina. a indica activo y m mantenimiento',
  `idoperador` int(11) NOT NULL COMMENT 'Referencia de operador',
  PRIMARY KEY  (`id`),
  KEY `fk_maquina_operador1` (`idoperador`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Las máquinas que se alquilan' AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `maquina`
-- 

INSERT INTO `maquina` VALUES (1, 'Tractor 2010 con arado', 'a', 2);
INSERT INTO `maquina` VALUES (2, 'Tractor 2011 con arado', 'a', 1);
INSERT INTO `maquina` VALUES (3, 'Tractor 2010 con rastra', 'a', 2);
INSERT INTO `maquina` VALUES (4, 'Tractor 2011 con rastra', 'a', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `opciones`
-- 

CREATE TABLE `opciones` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de la opción',
  `nombre` varchar(100) NOT NULL COMMENT 'Nombre de la opción',
  `descripcion` text NOT NULL COMMENT 'Descripción de la opción',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Opciones del sistema.' AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `opciones`
-- 

INSERT INTO `opciones` VALUES (1, 'limite_dia', '8');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `operador`
-- 

CREATE TABLE `operador` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identificador del operador',
  `nombres` varchar(45) NOT NULL COMMENT 'Nombres completos del operador',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Los que operan las máquinas' AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `operador`
-- 

INSERT INTO `operador` VALUES (1, 'Mario Coya AuccapiÃ±a');
INSERT INTO `operador` VALUES (2, 'Carlos Sihua Quispe');

-- 
-- Filtros para las tablas descargadas (dump)
-- 

-- 
-- Filtros para la tabla `alquiler`
-- 
ALTER TABLE `alquiler`
  ADD CONSTRAINT `fk_alquiler_cliente1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_alquiler_lugar1` FOREIGN KEY (`idlugar`) REFERENCES `lugar` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_alquiler_maquina1` FOREIGN KEY (`idmaquina`) REFERENCES `maquina` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

-- 
-- Filtros para la tabla `mantenimiento`
-- 
ALTER TABLE `mantenimiento`
  ADD CONSTRAINT `fk_mantenimiento_maquina1` FOREIGN KEY (`idmaquina`) REFERENCES `maquina` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

-- 
-- Filtros para la tabla `maquina`
-- 
ALTER TABLE `maquina`
  ADD CONSTRAINT `fk_maquina_operador1` FOREIGN KEY (`idoperador`) REFERENCES `operador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
